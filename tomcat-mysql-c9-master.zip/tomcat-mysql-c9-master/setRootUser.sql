USE test;

SET PASSWORD FOR 'root'@'localhost' = PASSWORD("123456");